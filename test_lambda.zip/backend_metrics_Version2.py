"""
Financial metrics computation (net profit, Sharpe, RSI, etc.).
"""
def compute_metrics(trade_results):
    # TODO: Implement real metrics calculation
    return {"net_profit": 0, "sharpe": 0, "rsi": 0}